
let myStringLength = 0;
let myString = "this is a test".
console.log(myString);
myStringLength = myString.length;
console.log(myString.length);

