let myFavFood =[];
console.log('the value of my array is'); + (myFavFood =['Pizza','burger','pasta','cake']);
console.log(myFavFood);

let myFavAnimals= ['Cat','Dog','Dinosaur','Donkey'];
console.log(myFavAnimals);
myFavAnimals.push('babypig');
console.log(myFavAnimals);
 