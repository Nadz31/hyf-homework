let typeNumber = 42;
console.log('The value of my variable typeNumber is: ' + typeNumber);


let typeString ='blubber';
console.log('The value of my variable typeString is: ' + typeString);


let typeBoolean = true;
console.log('The value of my variable typeBoolean is: ' + typeBoolean);


let typeUndefined = undefined;
console.log('The value of my variable typeUndefined is: ' + typeUndefined);


console.log('The type of variable typeNumber is:' + (typeof 42))
console.log('The type of variable typeString is:' + (typeof'blubber'))
console.log('The type of variable typetypeBoolean is:' + (typeof true))
console.log('The type of variable type is:' + (typeof undefined))