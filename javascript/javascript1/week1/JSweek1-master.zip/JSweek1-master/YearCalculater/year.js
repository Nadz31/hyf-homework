const yearOfBirth = 1990;
const futureYear = 2045;
const age = yearOfBirth - futureYear;
console.log('You will be'+ age +'years old in year' + futureYear);