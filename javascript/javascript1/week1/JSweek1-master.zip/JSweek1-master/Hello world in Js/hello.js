const English = "Hello world";
const Urdu = "Assalam-u-Alaikum Duniya";
const Persian = "Salam Duniya";
const Danish = "Hej Verden";
const Arabic = "Marhaba Bil-Alam";

console.log(English + "\n" + Urdu + "\n" + Persian + "\n" + Danish + "\n" + Arabic);


