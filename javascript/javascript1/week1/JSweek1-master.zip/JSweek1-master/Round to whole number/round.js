var a = Math.round(7.25);
console.log(a);